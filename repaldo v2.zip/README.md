
# repo_ionic_3

![546554645232424222](https://user-images.githubusercontent.com/81184929/132925069-8b30c7d1-4e3d-49f8-827b-f061c6cd0baa.PNG)

(self["webpackChunkmyApp"] = self["webpackChunkmyApp"] || []).push([["src_app_acceso_acceso_module_ts"],{

/***/ 4186:
/*!*************************************************!*\
  !*** ./src/app/acceso/acceso-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccesoPageRoutingModule": () => (/* binding */ AccesoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _acceso_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./acceso.page */ 3814);




const routes = [
    {
        path: '',
        component: _acceso_page__WEBPACK_IMPORTED_MODULE_0__.AccesoPage
    }
];
let AccesoPageRoutingModule = class AccesoPageRoutingModule {
};
AccesoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AccesoPageRoutingModule);



/***/ }),

/***/ 8190:
/*!*****************************************!*\
  !*** ./src/app/acceso/acceso.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccesoPageModule": () => (/* binding */ AccesoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _acceso_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./acceso-routing.module */ 4186);
/* harmony import */ var _acceso_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./acceso.page */ 3814);







let AccesoPageModule = class AccesoPageModule {
};
AccesoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _acceso_routing_module__WEBPACK_IMPORTED_MODULE_0__.AccesoPageRoutingModule
        ],
        declarations: [_acceso_page__WEBPACK_IMPORTED_MODULE_1__.AccesoPage]
    })
], AccesoPageModule);



/***/ }),

/***/ 3814:
/*!***************************************!*\
  !*** ./src/app/acceso/acceso.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccesoPage": () => (/* binding */ AccesoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_acceso_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./acceso.page.html */ 8890);
/* harmony import */ var _acceso_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./acceso.page.scss */ 8);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);





let AccesoPage = class AccesoPage {
    constructor(alertCtrl) {
        this.alertCtrl = alertCtrl;
        this.mostrarImagen = false;
    }
    displayImage() {
        this.mostrarImagen = !this.mostrarImagen;
    }
};
AccesoPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.AlertController }
];
AccesoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-acceso',
        template: _raw_loader_acceso_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_acceso_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AccesoPage);



/***/ }),

/***/ 8:
/*!*****************************************!*\
  !*** ./src/app/acceso/acceso.page.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY2Nlc28ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 8890:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/acceso/acceso.page.html ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Acceso</ion-title>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"login\"></ion-back-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content class=\"ion-padding ion-text-center\">\r\n  <div class=\"logo\">\r\n    <img\r\n      src=\"https://colegiocarlosoviedo.cl/wp-content/uploads/2020/04/logo_normal.png\"\r\n      alt=\"\"\r\n    />\r\n  </div>\r\n  <div>\r\n    <h2>Generador QR para Docentes</h2>\r\n    <p>Presione el botón azul y comparta este código QR con sus estudiantes</p>\r\n    <br />\r\n    <ion-button\r\n      expand=\"block\"\r\n      shape=\"round\"\r\n      class=\"btn-login\"\r\n      (click)=\"displayImage()\"\r\n      >Generar QR</ion-button\r\n    >\r\n    <ion-card *ngIf=\"mostrarImagen\">\r\n      <img src=\"../assets/codigoduoc.png\" />\r\n    </ion-card>\r\n  </div>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_acceso_acceso_module_ts.js.map
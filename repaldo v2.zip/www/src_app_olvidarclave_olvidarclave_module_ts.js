(self["webpackChunkmyApp"] = self["webpackChunkmyApp"] || []).push([["src_app_olvidarclave_olvidarclave_module_ts"],{

/***/ 6971:
/*!*************************************************************!*\
  !*** ./src/app/olvidarclave/olvidarclave-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OlvidarclavePageRoutingModule": () => (/* binding */ OlvidarclavePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _olvidarclave_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./olvidarclave.page */ 4347);




const routes = [
    {
        path: '',
        component: _olvidarclave_page__WEBPACK_IMPORTED_MODULE_0__.OlvidarclavePage
    }
];
let OlvidarclavePageRoutingModule = class OlvidarclavePageRoutingModule {
};
OlvidarclavePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OlvidarclavePageRoutingModule);



/***/ }),

/***/ 2200:
/*!*****************************************************!*\
  !*** ./src/app/olvidarclave/olvidarclave.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OlvidarclavePageModule": () => (/* binding */ OlvidarclavePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _olvidarclave_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./olvidarclave-routing.module */ 6971);
/* harmony import */ var _olvidarclave_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./olvidarclave.page */ 4347);







let OlvidarclavePageModule = class OlvidarclavePageModule {
};
OlvidarclavePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _olvidarclave_routing_module__WEBPACK_IMPORTED_MODULE_0__.OlvidarclavePageRoutingModule
        ],
        declarations: [_olvidarclave_page__WEBPACK_IMPORTED_MODULE_1__.OlvidarclavePage]
    })
], OlvidarclavePageModule);



/***/ }),

/***/ 4347:
/*!***************************************************!*\
  !*** ./src/app/olvidarclave/olvidarclave.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OlvidarclavePage": () => (/* binding */ OlvidarclavePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_olvidarclave_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./olvidarclave.page.html */ 3902);
/* harmony import */ var _olvidarclave_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./olvidarclave.page.scss */ 367);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);





let OlvidarclavePage = class OlvidarclavePage {
    constructor(alertCtrl) {
        this.alertCtrl = alertCtrl;
    }
    showAlert() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Enlace Enviado',
                subHeader: '',
                message: 'Te hemos enviado el enlace para cambiar tu contraseña',
                buttons: ['Cerrar']
            });
            yield alert.present();
            const result = yield alert.onDidDismiss();
            console.log(result);
        });
    }
};
OlvidarclavePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController }
];
OlvidarclavePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-olvidarclave',
        template: _raw_loader_olvidarclave_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_olvidarclave_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], OlvidarclavePage);



/***/ }),

/***/ 367:
/*!*****************************************************!*\
  !*** ./src/app/olvidarclave/olvidarclave.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".logo {\n  margin-top: 20%;\n}\n.logo img {\n  height: 120px;\n}\n.form {\n  margin-top: 30px;\n}\n.form ion-item {\n  border-radius: 5px;\n  border-color: #f6b200;\n  border-width: 2px;\n  border-style: solid;\n  margin-bottom: 10px;\n}\nion-button {\n  text-transform: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9sdmlkYXJjbGF2ZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0FBQ0Y7QUFBRTtFQUNFLGFBQUE7QUFFSjtBQUVBO0VBQ0UsZ0JBQUE7QUFDRjtBQUFFO0VBQ0Usa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQUVKO0FBRUE7RUFDRSxvQkFBQTtBQUNGIiwiZmlsZSI6Im9sdmlkYXJjbGF2ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubG9nbyB7XHJcbiAgbWFyZ2luLXRvcDogMjAlO1xyXG4gIGltZyB7XHJcbiAgICBoZWlnaHQ6IDEyMHB4O1xyXG4gIH1cclxufVxyXG5cclxuLmZvcm0ge1xyXG4gIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgaW9uLWl0ZW0ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiByZ2IoMjQ2LCAxNzgsIDAsIDI1NSk7XHJcbiAgICBib3JkZXItd2lkdGg6IDJweDtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gIH1cclxufVxyXG5cclxuaW9uLWJ1dHRvbiB7XHJcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 3902:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/olvidarclave/olvidarclave.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Recuperar Clave</ion-title>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"login\"></ion-back-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content class=\"ion-padding ion-text-center\">\r\n  <div class=\"logo\">\r\n    <img\r\n      src=\"https://colegiocarlosoviedo.cl/wp-content/uploads/2020/04/logo_normal.png\"\r\n      alt=\"\"\r\n    />\r\n  </div>\r\n  <div>\r\n    <h1>Recuperar Contraseña</h1>\r\n    <p></p>\r\n    <p>\r\n      Introduce tu dirección de correo electrónico y te enviaremos un enlace\r\n      para restablecer tu contraseña\r\n    </p>\r\n  </div>\r\n  <div class=\"form\">\r\n    <ion-item lines=\"none\">\r\n      <ion-input [(ngModel)]=\"email\" placeholder=\"Ingrese Email\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-button (click)=\"showAlert()\" color=\"dark\" expand=\"block\"\r\n      >Crear Cuenta</ion-button\r\n    >\r\n  </div>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_olvidarclave_olvidarclave_module_ts.js.map
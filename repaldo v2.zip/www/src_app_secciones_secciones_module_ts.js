(self["webpackChunkmyApp"] = self["webpackChunkmyApp"] || []).push([["src_app_secciones_secciones_module_ts"],{

/***/ 6755:
/*!*******************************************************!*\
  !*** ./src/app/secciones/secciones-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SeccionesPageRoutingModule": () => (/* binding */ SeccionesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _secciones_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./secciones.page */ 4038);




const routes = [
    {
        path: '',
        component: _secciones_page__WEBPACK_IMPORTED_MODULE_0__.SeccionesPage
    }
];
let SeccionesPageRoutingModule = class SeccionesPageRoutingModule {
};
SeccionesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SeccionesPageRoutingModule);



/***/ }),

/***/ 1919:
/*!***********************************************!*\
  !*** ./src/app/secciones/secciones.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SeccionesPageModule": () => (/* binding */ SeccionesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _secciones_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./secciones-routing.module */ 6755);
/* harmony import */ var _secciones_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./secciones.page */ 4038);







let SeccionesPageModule = class SeccionesPageModule {
};
SeccionesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _secciones_routing_module__WEBPACK_IMPORTED_MODULE_0__.SeccionesPageRoutingModule
        ],
        declarations: [_secciones_page__WEBPACK_IMPORTED_MODULE_1__.SeccionesPage]
    })
], SeccionesPageModule);



/***/ }),

/***/ 4038:
/*!*********************************************!*\
  !*** ./src/app/secciones/secciones.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SeccionesPage": () => (/* binding */ SeccionesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_secciones_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./secciones.page.html */ 6823);
/* harmony import */ var _secciones_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./secciones.page.scss */ 3892);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);





let SeccionesPage = class SeccionesPage {
    constructor(alertCtrl) {
        this.alertCtrl = alertCtrl;
    }
    showConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const confirm = yield this.alertCtrl.create({
                header: 'Confirmar',
                message: '¿Está seguro que quiere cerrar sesión?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancelar Acción');
                        }
                    },
                    {
                        text: 'Salir',
                        handler: () => {
                            console.log('Cerrando Sesión');
                        }
                    }
                ]
            });
            yield confirm.present();
        });
    }
};
SeccionesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController }
];
SeccionesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-secciones',
        template: _raw_loader_secciones_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_secciones_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SeccionesPage);



/***/ }),

/***/ 3892:
/*!***********************************************!*\
  !*** ./src/app/secciones/secciones.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZWNjaW9uZXMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 6823:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/secciones/secciones.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Acceso</ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"login\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"ion-padding ion-text-center\">\n  <div class=\"logo\">\n    <img\n      src=\"https://colegiocarlosoviedo.cl/wp-content/uploads/2020/04/logo_normal.png\"\n      alt=\"\"\n    />\n  </div>\n  <!-- List of Text Items -->\n  <ion-list>\n    <ion-item>\n      <ion-label routerLink=\"/acceso\">Sección 007D - Arquitectura</ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label routerLink=\"/acceso\"\n        >Sección 005D - Etica de Trabajo</ion-label\n      >\n    </ion-item>\n    <ion-item>\n      <ion-label routerLink=\"/acceso\"\n        >Sección 006D - Estadistica Descriptiva</ion-label\n      >\n    </ion-item>\n    <ion-item>\n      <ion-label routerLink=\"/acceso\"\n        >Sección 007D - Calidad de Software</ion-label\n      >\n    </ion-item>\n    <ion-item>\n      <ion-label routerLink=\"/acceso\"\n        >Sección 008D - Programación de Apps</ion-label\n      >\n    </ion-item>\n  </ion-list>\n  <br />\n  <br />\n  <ion-button (click)=\"showConfirm()\">Cerrar Sesión</ion-button>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_secciones_secciones_module_ts.js.map
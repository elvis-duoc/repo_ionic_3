import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dual',
  templateUrl: './dual.page.html',
  styleUrls: ['./dual.page.scss'],
})
export class DualPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cuentacreada',
  templateUrl: './cuentacreada.page.html',
  styleUrls: ['./cuentacreada.page.scss'],
})
export class CuentacreadaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
